package com.carrental.web;

import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;

public class ReservationForm {

    @NotNull(message = "Choose a start date.")
    private LocalDate startDate;

    @NotNull(message = "Choose an end date.")
    private LocalDate endDate;

    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
    public LocalDate getEndDate() { return endDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }
}