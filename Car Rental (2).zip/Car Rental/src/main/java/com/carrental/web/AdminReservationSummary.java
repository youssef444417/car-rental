package com.carrental.web;

import com.carrental.model.ReservationStatus;

import java.math.BigDecimal;
import java.time.LocalDate;

public record AdminReservationSummary(Long id, Long customerId, String customerName, String customerEmail,
                                      Long carId, String carBrand, String carModel,
                                      LocalDate startDate, LocalDate endDate,
                                      BigDecimal dailyPrice, BigDecimal totalPrice,
                                      ReservationStatus status) {
}