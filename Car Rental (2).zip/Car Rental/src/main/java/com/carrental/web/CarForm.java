package com.carrental.web;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;

public class CarForm {

    @NotBlank(message = "Enter a car brand.")
    @Size(max = 60, message = "Brand must be 60 characters or fewer.")
    private String brand;

    @NotBlank(message = "Enter a car model.")
    @Size(max = 80, message = "Model must be 80 characters or fewer.")
    private String model;

    @NotNull(message = "Enter the model year.")
    @Min(value = 1886, message = "Year must be 1886 or later.")
    @Max(value = 2100, message = "Year must be 2100 or earlier.")
    private Integer year;

    @NotBlank(message = "Enter a car category.")
    @Size(max = 40, message = "Category must be 40 characters or fewer.")
    private String category;

    @Size(max = 2000, message = "Description must be 2000 characters or fewer.")
    private String description;

    @NotNull(message = "Enter a daily price.")
    @DecimalMin(value = "0.01", message = "Daily price must be greater than zero.")
    @Digits(integer = 8, fraction = 2, message = "Use up to 8 whole-number digits and 2 decimal places.")
    private BigDecimal pricePerDay;

    @Size(max = 1000, message = "Image path must be 1000 characters or fewer.")
    @Pattern(regexp = "^(https?://.*|/images/[A-Za-z0-9_-]+(?:/[A-Za-z0-9_-]+)*(?:\\.[A-Za-z0-9]+)?)?$",
            message = "Use an http(s) URL or a local path under /images/.")
    private String imageUrl;

    private boolean available = true;

    public String getBrand() { return brand; }
    public void setBrand(String brand) { this.brand = brand; }
    public String getModel() { return model; }
    public void setModel(String model) { this.model = model; }
    public Integer getYear() { return year; }
    public void setYear(Integer year) { this.year = year; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public BigDecimal getPricePerDay() { return pricePerDay; }
    public void setPricePerDay(BigDecimal pricePerDay) { this.pricePerDay = pricePerDay; }
    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }
}