package com.carrental.web;

public record AdminCustomerSummary(Long id, String fullName, String email) {
}