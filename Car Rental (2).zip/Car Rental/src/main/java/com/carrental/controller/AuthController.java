package com.carrental.controller;

import com.carrental.service.DuplicateEmailException;
import com.carrental.service.UserService;
import com.carrental.web.RegistrationForm;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;

import java.nio.charset.StandardCharsets;

@Controller
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @InitBinder("registrationForm")
    void trimRegistrationTextFields(WebDataBinder binder) {
        binder.registerCustomEditor(String.class, "fullName", new StringTrimmerEditor(true));
        binder.registerCustomEditor(String.class, "email", new StringTrimmerEditor(true));
    }

    @GetMapping("/login")
    public String showLoginPage() {
        return "login";
    }

    @GetMapping("/register")
    public String showRegistrationPage(Model model) {
        if (!model.containsAttribute("registrationForm")) {
            model.addAttribute("registrationForm", new RegistrationForm());
        }
        return "register";
    }

    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("registrationForm") RegistrationForm form,
                           BindingResult bindingResult) {
        if (form.getPassword() != null && form.getConfirmPassword() != null
                && !form.getPassword().equals(form.getConfirmPassword())) {
            bindingResult.rejectValue("confirmPassword", "password.mismatch", "The passwords do not match.");
        }
        if (form.getPassword() != null
                && form.getPassword().getBytes(StandardCharsets.UTF_8).length > 72) {
            bindingResult.rejectValue("password", "password.encodedLength",
                    "This password is too long. Use a shorter password.");
        }
        if (bindingResult.hasErrors()) {
            return "register";
        }

        try {
            userService.registerCustomer(form.getFullName(), form.getEmail(), form.getPassword());
        } catch (DuplicateEmailException exception) {
            bindingResult.rejectValue("email", "email.duplicate",
                    "This email is already registered. Sign in or use a different address.");
            return "register";
        } catch (IllegalArgumentException exception) {
            bindingResult.rejectValue("password", "password.invalid", "Choose a shorter password and try again.");
            return "register";
        }

        return "redirect:/login?registered";
    }
}
