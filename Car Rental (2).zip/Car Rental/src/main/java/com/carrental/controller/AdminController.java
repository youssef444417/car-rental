package com.carrental.controller;

import com.carrental.model.Car;
import com.carrental.model.ReservationStatus;
import com.carrental.service.AdminOperationException;
import com.carrental.service.AdminService;
import com.carrental.service.ReservationException;
import com.carrental.web.AdminCustomerSummary;
import com.carrental.web.CarForm;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AdminController {

    private final AdminService adminService;

    public AdminController(AdminService adminService) {
        this.adminService = adminService;
    }

    @GetMapping("/admin")
    public String showAdminHome(Model model) {
        model.addAttribute("stats", adminService.dashboardStats());
        return "admin";
    }

    @GetMapping("/admin/cars")
    public String showCars(@RequestParam(required = false) String search, Model model) {
        model.addAttribute("cars", adminService.findCars(search));
        model.addAttribute("search", search == null ? "" : search.trim());
        return "admin-cars";
    }

    @GetMapping("/admin/cars/new")
    public String showCreateCarForm(Model model) {
        prepareCarForm(model, new CarForm(), null);
        return "admin-car-form";
    }

    @PostMapping("/admin/cars")
    public String createCar(@Valid @ModelAttribute("carForm") CarForm form,
                            BindingResult bindingResult, Model model,
                            RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            prepareCarForm(model, form, null);
            return "admin-car-form";
        }
        try {
            adminService.saveCar(null, form);
            redirectAttributes.addFlashAttribute("adminMessage", "Car added to the catalog.");
            return "redirect:/admin/cars";
        } catch (AdminOperationException exception) {
            bindingResult.reject("car.invalid", exception.getMessage());
            prepareCarForm(model, form, null);
            return "admin-car-form";
        }
    }

    @GetMapping("/admin/cars/{carId}/edit")
    public String showEditCarForm(@PathVariable Long carId, Model model,
                                  RedirectAttributes redirectAttributes) {
        try {
            prepareCarForm(model, toCarForm(adminService.findCar(carId)), carId);
            return "admin-car-form";
        } catch (AdminOperationException exception) {
            redirectAttributes.addFlashAttribute("adminError", exception.getMessage());
            return "redirect:/admin/cars";
        }
    }

    @PostMapping("/admin/cars/{carId}")
    public String updateCar(@PathVariable Long carId,
                            @Valid @ModelAttribute("carForm") CarForm form,
                            BindingResult bindingResult, Model model,
                            RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            prepareCarForm(model, form, carId);
            return "admin-car-form";
        }
        try {
            adminService.saveCar(carId, form);
            redirectAttributes.addFlashAttribute("adminMessage", "Car details updated.");
            return "redirect:/admin/cars";
        } catch (AdminOperationException exception) {
            bindingResult.reject("car.invalid", exception.getMessage());
            prepareCarForm(model, form, carId);
            return "admin-car-form";
        }
    }

    @PostMapping("/admin/cars/{carId}/availability")
    public String changeAvailability(@PathVariable Long carId, @RequestParam boolean available,
                                     RedirectAttributes redirectAttributes) {
        try {
            adminService.changeAvailability(carId, available);
            redirectAttributes.addFlashAttribute("adminMessage", "Car availability updated.");
        } catch (AdminOperationException exception) {
            redirectAttributes.addFlashAttribute("adminError", exception.getMessage());
        }
        return "redirect:/admin/cars";
    }

    @PostMapping("/admin/cars/{carId}/delete")
    public String deleteCar(@PathVariable Long carId, RedirectAttributes redirectAttributes) {
        try {
            adminService.deleteCar(carId);
            redirectAttributes.addFlashAttribute("adminMessage", "Car deleted from the catalog.");
        } catch (AdminOperationException exception) {
            redirectAttributes.addFlashAttribute("adminError", exception.getMessage());
        }
        return "redirect:/admin/cars";
    }

    @GetMapping("/admin/reservations")
    public String showReservations(@RequestParam(required = false) String status, Model model) {
        ReservationStatus selectedStatus = null;
        String filterError = null;
        if (status != null && !status.isBlank()) {
            try {
                selectedStatus = ReservationStatus.valueOf(status);
            } catch (IllegalArgumentException exception) {
                filterError = "Choose a valid reservation status.";
            }
        }
        model.addAttribute("reservations", adminService.findReservations(selectedStatus));
        model.addAttribute("selectedStatus", selectedStatus == null ? "" : selectedStatus.name());
        model.addAttribute("statuses", ReservationStatus.values());
        model.addAttribute("filterError", filterError);
        model.addAttribute("today", java.time.LocalDate.now());
        return "admin-reservations";
    }

    @PostMapping("/admin/reservations/{reservationId}/status")
    public String changeReservationStatus(@PathVariable Long reservationId,
                                          @RequestParam String status,
                                          RedirectAttributes redirectAttributes) {
        try {
            adminService.changeReservationStatus(reservationId, ReservationStatus.valueOf(status));
            redirectAttributes.addFlashAttribute("adminMessage", "Reservation status updated.");
        } catch (IllegalArgumentException | ReservationException exception) {
            redirectAttributes.addFlashAttribute("adminError", exception.getMessage());
        }
        return "redirect:/admin/reservations";
    }

    @PostMapping("/admin/reservations/{reservationId}/dates")
    public String modifyReservation(@PathVariable Long reservationId, @RequestParam java.time.LocalDate startDate,
                                    @RequestParam java.time.LocalDate endDate, RedirectAttributes redirectAttributes) {
        try {
            adminService.modifyReservation(reservationId, startDate, endDate);
            redirectAttributes.addFlashAttribute("adminMessage", "Reservation dates updated.");
        } catch (ReservationException exception) {
            redirectAttributes.addFlashAttribute("adminError", exception.getMessage());
        }
        return "redirect:/admin/reservations";
    }

    @PostMapping("/admin/reservations/{reservationId}/delete")
    public String deleteReservation(@PathVariable Long reservationId, RedirectAttributes redirectAttributes) {
        try {
            adminService.deleteReservation(reservationId);
            redirectAttributes.addFlashAttribute("adminMessage", "Future reservation deleted.");
        } catch (ReservationException exception) {
            redirectAttributes.addFlashAttribute("adminError", exception.getMessage());
        }
        return "redirect:/admin/reservations";
    }

    @GetMapping("/admin/customers")
    public String showCustomers(@RequestParam(required = false) String search, Model model) {
        try {
            model.addAttribute("customers", adminService.findCustomers(search));
        } catch (AdminOperationException exception) {
            model.addAttribute("customers", java.util.List.of());
            model.addAttribute("adminError", exception.getMessage());
        }
        model.addAttribute("search", search == null ? "" : search.trim());
        return "admin-customers";
    }

    @GetMapping("/admin/customers/{customerId}")
    public String showCustomer(@PathVariable Long customerId, Model model,
                               RedirectAttributes redirectAttributes) {
        try {
            AdminCustomerSummary customer = adminService.findCustomer(customerId);
            model.addAttribute("customer", customer);
            model.addAttribute("reservations", adminService.findCustomerReservations(customerId));
            return "admin-customer-details";
        } catch (AdminOperationException exception) {
            redirectAttributes.addFlashAttribute("adminError", exception.getMessage());
            return "redirect:/admin/customers";
        }
    }

    @PostMapping("/admin/customers/{customerId}")
    public String updateCustomer(@PathVariable Long customerId, @RequestParam String fullName,
                                 @RequestParam String email, RedirectAttributes redirectAttributes) {
        try {
            adminService.modifyCustomer(customerId, fullName, email);
            redirectAttributes.addFlashAttribute("adminMessage", "Customer details updated.");
        } catch (AdminOperationException | com.carrental.service.DuplicateEmailException exception) {
            redirectAttributes.addFlashAttribute("adminError", exception.getMessage());
        }
        return "redirect:/admin/customers/" + customerId;
    }

    @PostMapping("/admin/customers/{customerId}/delete")
    public String deleteCustomer(@PathVariable Long customerId, RedirectAttributes redirectAttributes) {
        try {
            adminService.deleteCustomer(customerId);
            redirectAttributes.addFlashAttribute("adminMessage", "Customer account deleted.");
            return "redirect:/admin/customers";
        } catch (AdminOperationException exception) {
            redirectAttributes.addFlashAttribute("adminError", exception.getMessage());
            return "redirect:/admin/customers/" + customerId;
        }
    }

    private void prepareCarForm(Model model, CarForm form, Long carId) {
        model.addAttribute("carForm", form);
        model.addAttribute("carId", carId);
        model.addAttribute("formTitle", carId == null ? "Add car" : "Edit car");
        model.addAttribute("formAction", carId == null ? "/admin/cars" : "/admin/cars/" + carId);
        model.addAttribute("categories", adminService.findCategories());
    }

    private CarForm toCarForm(Car car) {
        CarForm form = new CarForm();
        form.setBrand(car.getBrand());
        form.setModel(car.getModel());
        form.setYear(car.getYear());
        form.setCategory(car.getCategory());
        form.setDescription(car.getDescription());
        form.setPricePerDay(car.getPricePerDay());
        form.setImageUrl(car.getImageUrl());
        form.setAvailable(car.isAvailable());
        return form;
    }
}
