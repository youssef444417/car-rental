package com.carrental.controller;

import com.carrental.model.Car;
import com.carrental.security.CustomUserDetails;
import com.carrental.service.CarService;
import com.carrental.service.ReservationException;
import com.carrental.service.ReservationService;
import com.carrental.web.ReservationForm;
import jakarta.validation.Valid;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;

@Controller
public class ReservationController {

    private final ReservationService reservationService;
    private final CarService carService;

    public ReservationController(ReservationService reservationService, CarService carService) {
        this.reservationService = reservationService;
        this.carService = carService;
    }

    @PostMapping("/cars/{carId}/reservations")
    public String createReservation(@PathVariable Long carId,
                                    @Valid @ModelAttribute("reservationForm") ReservationForm form,
                                    BindingResult bindingResult,
                                    @AuthenticationPrincipal CustomUserDetails currentUser,
                                    Model model,
                                    RedirectAttributes redirectAttributes) {
        if (!bindingResult.hasErrors()) {
            try {
                reservationService.createReservation(currentUser.getId(), carId,
                        form.getStartDate(), form.getEndDate());
                redirectAttributes.addFlashAttribute("reservationMessage", "Your reservation is confirmed.");
                return "redirect:/account/reservations";
            } catch (ReservationException exception) {
                bindingResult.reject("reservation.invalid", exception.getMessage());
            }
        }

        Car car = carService.findCarById(carId);
        model.addAttribute("car", car);
        model.addAttribute("minimumStartDate", LocalDate.now());
        return "car-details";
    }
}