package com.carrental.controller;

import com.carrental.model.Car;
import com.carrental.service.CarService;
import com.carrental.web.ReservationForm;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CarController {

    private final CarService carService;

    public CarController(CarService carService) {
        this.carService = carService;
    }

    @GetMapping("/cars")
    public String listCars(@RequestParam(required = false) String search,
                           @RequestParam(required = false) String category,
                           @RequestParam(defaultValue = "false") boolean available,
                           Model model) {
        model.addAttribute("cars", carService.findCars(search, category, available));
        model.addAttribute("categories", carService.findCategories());
        model.addAttribute("search", search == null ? "" : search.trim());
        model.addAttribute("selectedCategory", category == null ? "" : category.trim());
        model.addAttribute("availableOnly", available);
        return "cars";
    }

    @GetMapping("/cars/{id}")
    public String showCarDetails(@PathVariable Long id, Model model) {
        Car car = carService.findCarById(id);
        model.addAttribute("car", car);
        model.addAttribute("reservationForm", new ReservationForm());
        model.addAttribute("minimumStartDate", java.time.LocalDate.now());
        return "car-details";
    }
}
