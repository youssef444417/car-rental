package com.carrental.controller;

import com.carrental.security.CustomUserDetails;
import com.carrental.service.ReservationException;
import com.carrental.service.ReservationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;

@Controller
public class AccountController {

    @Autowired 
    private ReservationService reservationService;

   

    @GetMapping("/account")
    public String showAccountPage(@AuthenticationPrincipal CustomUserDetails currentUser, Model model) {
        model.addAttribute("currentUser", currentUser);
        return "account";
    }

    @GetMapping("/account/reservations")
    public String showReservations(@AuthenticationPrincipal CustomUserDetails currentUser, Model model) {
        model.addAttribute("currentUser", currentUser);
        model.addAttribute("reservations", reservationService.findReservationsForCustomer(currentUser.getId()));
        model.addAttribute("today", LocalDate.now());
        return "reservations";
    }

    @PostMapping("/account/reservations/{reservationId}/cancel")
    public String cancelReservation(@PathVariable Long reservationId,
                                    @AuthenticationPrincipal CustomUserDetails currentUser,
                                    RedirectAttributes redirectAttributes) {
        try {
            reservationService.cancelReservation(currentUser.getId(), reservationId);
            redirectAttributes.addFlashAttribute("reservationMessage", "Your reservation was cancelled.");
        } catch (ReservationException exception) {
            redirectAttributes.addFlashAttribute("reservationError", exception.getMessage());
        }
        return "redirect:/account/reservations";
    }
}
