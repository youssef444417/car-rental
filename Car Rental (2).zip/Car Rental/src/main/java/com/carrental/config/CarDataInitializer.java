package com.carrental.config;

import com.carrental.model.Car;
import com.carrental.repository.CarRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Configuration(proxyBeanMethods = false)
@Profile("dev")
@ConditionalOnProperty(prefix = "app.sample-data", name = "enabled", havingValue = "true")
public class CarDataInitializer {

    private static final Map<String, String> SAMPLE_IMAGE_PATHS = Map.of(
            "Toyota|Corolla", "/images/cars/toyota-corolla-sedan.jpg",
            "Volkswagen|Golf", "/images/cars/volkswagen-golf-hatchback.jpg",
            "Hyundai|Tucson", "/images/cars/hyundai-tucson-suv.jpg",
            "BMW|3 Series", "/images/cars/bmw-3-series-luxury.jpg");

    @Bean
    CommandLineRunner loadSampleCars(CarRepository carRepository) {
        return args -> {
            if (carRepository.count() == 0) {
                carRepository.saveAll(List.of(
                        new Car("Toyota", "Corolla", 2023, "Sedan", "A comfortable and efficient car for everyday trips.", new BigDecimal("48.00"), SAMPLE_IMAGE_PATHS.get("Toyota|Corolla"), true),
                        new Car("Volkswagen", "Golf", 2022, "Hatchback", "A compact, practical choice for city driving.", new BigDecimal("52.00"), SAMPLE_IMAGE_PATHS.get("Volkswagen|Golf"), true),
                        new Car("Hyundai", "Tucson", 2024, "SUV", "A spacious SUV with room for passengers and luggage.", new BigDecimal("79.00"), SAMPLE_IMAGE_PATHS.get("Hyundai|Tucson"), true),
                        new Car("BMW", "3 Series", 2023, "Luxury", "A refined sedan for a more comfortable journey.", new BigDecimal("115.00"), SAMPLE_IMAGE_PATHS.get("BMW|3 Series"), false)
                ));
                return;
            }

            List<Car> cars = carRepository.findAll();
            boolean imageReferencesUpdated = false;
            for (Car car : cars) {
                String imagePath = SAMPLE_IMAGE_PATHS.get(car.getBrand() + "|" + car.getModel());
                if (imagePath != null && (car.getImageUrl() == null || car.getImageUrl().isBlank())) {
                    car.setImageUrl(imagePath);
                    imageReferencesUpdated = true;
                }
            }
            if (imageReferencesUpdated) {
                carRepository.saveAll(cars);
            }
        };
    }
}
