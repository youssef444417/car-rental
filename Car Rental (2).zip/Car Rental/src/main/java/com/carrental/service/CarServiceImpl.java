package com.carrental.service;

import com.carrental.model.Car;
import com.carrental.repository.CarRepository;
import com.carrental.repository.ReservationRepository;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
@Transactional(readOnly = true)
public class CarServiceImpl implements CarService {

    private final CarRepository carRepository;
    private final ReservationRepository reservationRepository;

    public CarServiceImpl(CarRepository carRepository, ReservationRepository reservationRepository) {
        this.carRepository = carRepository;
        this.reservationRepository = reservationRepository;
    }

    @Override
    public List<Car> findCars(String search, String category, boolean availableOnly) {
        String normalizedSearch = normalizeFilter(search, 80, "Search");
        String normalizedCategory = normalizeFilter(category, 40, "Category");
        return carRepository.searchCatalog(normalizedSearch, normalizedCategory, availableOnly);
    }

    @Override
    public List<String> findCategories() {
        return carRepository.findAllCategories();
    }

    @Override
    public Car findCarById(Long id) {
        if (id == null || id < 1) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Car ID must be a positive number");
        }
        return carRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Car not found"));
    }

    @Override
    @Transactional
    public Car addCar(Car car) {
        return carRepository.save(car);
    }

    @Override
    @Transactional
    public Car modifyCar(Long id, Car updatedCar) {
        Car car = requireAdminCar(id);
        car.setBrand(updatedCar.getBrand());
        car.setModel(updatedCar.getModel());
        car.setYear(updatedCar.getYear());
        car.setCategory(updatedCar.getCategory());
        car.setDescription(updatedCar.getDescription());
        car.setPricePerDay(updatedCar.getPricePerDay());
        car.setImageUrl(updatedCar.getImageUrl());
        car.setAvailable(updatedCar.isAvailable());
        return carRepository.save(car);
    }

    @Override
    @Transactional
    public void changeAvailability(Long id, boolean available) {
        requireAdminCar(id).setAvailable(available);
    }

    @Override
    @Transactional
    public void deleteCar(Long id) {
        Car car = requireAdminCar(id);
        if (reservationRepository.existsByCar_Id(id)) {
            throw new AdminOperationException(
                    "This car has reservation history and cannot be deleted. Mark it unavailable instead.");
        }
        try {
            carRepository.delete(car);
            carRepository.flush();
        } catch (DataIntegrityViolationException exception) {
            throw new AdminOperationException(
                    "The database still references this car. Mark it unavailable instead.");
        }
    }

    private Car requireAdminCar(Long id) {
        try {
            return findCarById(id);
        } catch (ResponseStatusException exception) {
            throw new AdminOperationException("That car could not be found.");
        }
    }

    private String normalizeFilter(String value, int maxLength, String label) {
        if (value == null || value.isBlank()) {
            return null;
        }
        String trimmed = value.trim();
        if (trimmed.length() > maxLength) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    label + " must be at most " + maxLength + " characters");
        }
        return trimmed;
    }
}