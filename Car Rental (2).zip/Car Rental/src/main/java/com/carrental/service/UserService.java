package com.carrental.service;

import com.carrental.model.User;
import com.carrental.web.AdminCustomerSummary;

import java.util.List;
import java.util.Optional;

public interface UserService {

    User registerCustomer(String fullName, String email, String rawPassword);

    Optional<User> findById(Long id);

    User modifyCustomer(Long id, String fullName, String email);

    void deleteCustomer(Long id);

    List<AdminCustomerSummary> findCustomers(String search);

    AdminCustomerSummary findCustomer(Long id);
}
