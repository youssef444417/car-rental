package com.carrental.service;

import com.carrental.model.Car;
import com.carrental.model.ReservationStatus;
import com.carrental.model.Role;
import com.carrental.repository.CarRepository;
import com.carrental.repository.ReservationRepository;
import com.carrental.repository.UserRepository;
import com.carrental.web.AdminCustomerSummary;
import com.carrental.web.AdminReservationSummary;
import com.carrental.web.CarForm;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class AdminService {

    private final CarRepository carRepository;
    private final UserRepository userRepository;
    private final ReservationRepository reservationRepository;
    private final CarService carService;
    private final UserService userService;
    private final ReservationService reservationService;

    public AdminService(CarRepository carRepository, UserRepository userRepository,
                        ReservationRepository reservationRepository, CarService carService,
                        UserService userService, ReservationService reservationService) {
        this.carRepository = carRepository;
        this.userRepository = userRepository;
        this.reservationRepository = reservationRepository;
        this.carService = carService;
        this.userService = userService;
        this.reservationService = reservationService;
    }

    @Transactional(readOnly = true)
    public DashboardStats dashboardStats() {
        return new DashboardStats(carRepository.count(), carRepository.countByAvailableTrue(),
                userRepository.countByRole(Role.CUSTOMER), reservationRepository.count(),
                reservationRepository.countByStatus(ReservationStatus.CONFIRMED),
                reservationRepository.countByStatus(ReservationStatus.CANCELLED));
    }

    @Transactional(readOnly = true)
    public List<Car> findCars(String search) {
        try {
            return carService.findCars(search, null, false);
        } catch (ResponseStatusException exception) {
            throw new AdminOperationException("Search must be 80 characters or fewer.");
        }
    }

    @Transactional(readOnly = true)
    public List<String> findCategories() {
        return carService.findCategories();
    }

    @Transactional(readOnly = true)
    public Car findCar(Long id) {
        try {
            return carService.findCarById(id);
        } catch (ResponseStatusException exception) {
            throw new AdminOperationException("That car could not be found.");
        }
    }

    @Transactional
    public Car saveCar(Long id, CarForm form) {
        Car car = new Car(form.getBrand().trim(), form.getModel().trim(), form.getYear(),
            form.getCategory().trim(), form.getDescription() == null ? "" : form.getDescription().trim(),
            form.getPricePerDay(), form.getImageUrl() == null ? "" : form.getImageUrl().trim(),
            form.isAvailable());
        return id == null ? carService.addCar(car) : carService.modifyCar(id, car);
    }

    @Transactional
    public void changeAvailability(Long id, boolean available) {
        carService.changeAvailability(id, available);
    }

    @Transactional
    public void deleteCar(Long id) {
        carService.deleteCar(id);
    }

    @Transactional(readOnly = true)
    public List<AdminReservationSummary> findReservations(ReservationStatus status) {
        return reservationService.findReservations(status);
    }

    @Transactional
    public void changeReservationStatus(Long id, ReservationStatus status) {
        reservationService.changeStatusByAdmin(id, status);
    }

    @Transactional
    public void modifyReservation(Long id, java.time.LocalDate startDate, java.time.LocalDate endDate) {
        reservationService.modifyReservationByAdmin(id, startDate, endDate);
    }

    @Transactional
    public void deleteReservation(Long id) {
        reservationService.deleteReservationByAdmin(id);
    }

    @Transactional(readOnly = true)
    public List<AdminCustomerSummary> findCustomers(String search) {
        return userService.findCustomers(search);
    }

    @Transactional(readOnly = true)
    public AdminCustomerSummary findCustomer(Long id) {
        return userService.findCustomer(id);
    }

    @Transactional
    public void modifyCustomer(Long id, String fullName, String email) {
        userService.modifyCustomer(id, fullName, email);
    }

    @Transactional
    public void deleteCustomer(Long id) {
        userService.deleteCustomer(id);
    }

    @Transactional(readOnly = true)
    public List<AdminReservationSummary> findCustomerReservations(Long customerId) {
        return reservationService.findReservationsForCustomerByAdmin(customerId);
    }

    public record DashboardStats(long totalCars, long availableCars, long registeredCustomers,
                                 long totalReservations, long confirmedReservations, long cancelledReservations) {
    }
}
