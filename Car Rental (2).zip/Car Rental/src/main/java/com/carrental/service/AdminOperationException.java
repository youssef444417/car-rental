package com.carrental.service;

public class AdminOperationException extends RuntimeException {

    public AdminOperationException(String message) {
        super(message);
    }
}