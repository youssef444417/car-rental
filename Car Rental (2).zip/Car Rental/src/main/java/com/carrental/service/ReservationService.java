package com.carrental.service;

import com.carrental.model.Reservation;
import com.carrental.model.ReservationStatus;
import com.carrental.web.AdminReservationSummary;
import java.time.LocalDate;
import java.util.List;

public interface ReservationService {

    Reservation createReservation(Long userId, Long carId, LocalDate startDate, LocalDate endDate);

    List<Reservation> findReservationsForCustomer(Long userId);

    void cancelReservation(Long userId, Long reservationId);

    void changeStatusByAdmin(Long reservationId, ReservationStatus nextStatus);

    Reservation modifyReservationByAdmin(Long reservationId, LocalDate startDate, LocalDate endDate);

    void deleteReservationByAdmin(Long reservationId);

    List<AdminReservationSummary> findReservations(ReservationStatus status);

    List<AdminReservationSummary> findReservationsForCustomerByAdmin(Long customerId);
}
