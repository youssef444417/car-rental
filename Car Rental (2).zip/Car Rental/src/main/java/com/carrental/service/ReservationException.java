package com.carrental.service;

public class ReservationException extends RuntimeException {

    public ReservationException(String message) {
        super(message);
    }
}