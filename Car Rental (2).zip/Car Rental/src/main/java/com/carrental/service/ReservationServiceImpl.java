package com.carrental.service;

import com.carrental.model.Car;
import com.carrental.model.Reservation;
import com.carrental.model.ReservationStatus;
import com.carrental.model.Role;
import com.carrental.model.User;
import com.carrental.repository.CarRepository;
import com.carrental.repository.ReservationRepository;
import com.carrental.web.AdminReservationSummary;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

@Service
public class ReservationServiceImpl implements ReservationService {

    private static final int MAX_RENTAL_DAYS = 30;
    private static final List<ReservationStatus> AVAILABILITY_BLOCKING_STATUSES =
            List.of(ReservationStatus.CONFIRMED);

    private final ReservationRepository reservationRepository;
    private final UserService userService;
    private final CarRepository carRepository;

    public ReservationServiceImpl(ReservationRepository reservationRepository,
                                  UserService userService,
                                  CarRepository carRepository) {
        this.reservationRepository = reservationRepository;
        this.userService = userService;
        this.carRepository = carRepository;
    }

    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public Reservation createReservation(Long userId, Long carId, LocalDate startDate, LocalDate endDate) {
        long rentalDays = validateDates(startDate, endDate);
        User user = requireCustomer(userId);

        Car car = carRepository.findByIdForUpdate(carId)
                .orElseThrow(() -> new ReservationException("That car could not be found."));
        if (!car.isAvailable()) {
            throw new ReservationException("This car is currently unavailable.");
        }
        boolean overlaps = reservationRepository
                .existsByCar_IdAndStatusInAndStartDateLessThanAndEndDateGreaterThan(
                        carId, AVAILABILITY_BLOCKING_STATUSES, endDate, startDate);
        if (overlaps) {
            throw new ReservationException("This car already has a reservation for some of those dates.");
        }

        BigDecimal dailyPrice = car.getPricePerDay().setScale(2, RoundingMode.HALF_UP);
        BigDecimal totalPrice = dailyPrice.multiply(BigDecimal.valueOf(rentalDays))
                .setScale(2, RoundingMode.HALF_UP);
        Reservation reservation = new Reservation(user, car, startDate, endDate,
                ReservationStatus.CONFIRMED, dailyPrice, totalPrice);
        return reservationRepository.save(reservation);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Reservation> findReservationsForCustomer(Long userId) {
        requireCustomer(userId);
        return reservationRepository.findAllForUser(userId);
    }

    @Override
    @Transactional
    public void cancelReservation(Long userId, Long reservationId) {
        requireCustomer(userId);
        Reservation reservation = reservationRepository.findOwnedForUpdate(reservationId, userId)
                .orElseThrow(() -> new ReservationException("That reservation could not be found."));
        cancelConfirmedReservation(reservation);
    }

    @Override
    @Transactional
    public void changeStatusByAdmin(Long reservationId, ReservationStatus nextStatus) {
        if (nextStatus == null) {
            throw new ReservationException("Choose a reservation status.");
        }
        Reservation reservation = reservationRepository.findByIdForUpdate(reservationId)
                .orElseThrow(() -> new ReservationException("That reservation could not be found."));
        if (reservation.getStatus() != ReservationStatus.CONFIRMED) {
            throw new ReservationException("Only confirmed reservations can change status.");
        }
        if (nextStatus == ReservationStatus.CANCELLED) {
            cancelConfirmedReservation(reservation);
            return;
        }
        if (nextStatus == ReservationStatus.COMPLETED) {
            if (reservation.getEndDate().isAfter(LocalDate.now())) {
                throw new ReservationException("A reservation can only be completed after its end date.");
            }
            reservation.setStatus(ReservationStatus.COMPLETED);
            return;
        }
        throw new ReservationException("That reservation status transition is not allowed.");
    }

    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public Reservation modifyReservationByAdmin(Long reservationId, LocalDate startDate, LocalDate endDate) {
        long days = validateDates(startDate, endDate);
        Reservation reservation = reservationRepository.findByIdForUpdate(reservationId)
                .orElseThrow(() -> new ReservationException("That reservation could not be found."));
        if (reservation.getStatus() != ReservationStatus.CONFIRMED
                || !reservation.getStartDate().isAfter(LocalDate.now())) {
            throw new ReservationException("Only future confirmed reservations can be modified.");
        }
        Car car = carRepository.findByIdForUpdate(reservation.getCar().getId())
                .orElseThrow(() -> new ReservationException("That car could not be found."));
        if (!car.isAvailable() || reservationRepository.existsOverlappingReservation(car.getId(), reservationId,
                AVAILABILITY_BLOCKING_STATUSES, endDate, startDate)) {
            throw new ReservationException("The car is unavailable for those dates.");
        }
        reservation.setRentalDates(startDate, endDate,
                reservation.getDailyPriceSnapshot().multiply(BigDecimal.valueOf(days)).setScale(2, RoundingMode.HALF_UP));
        return reservation;
    }

    @Override
    @Transactional
    public void deleteReservationByAdmin(Long reservationId) {
        Reservation reservation = reservationRepository.findByIdForUpdate(reservationId)
                .orElseThrow(() -> new ReservationException("That reservation could not be found."));
        if (reservation.getStatus() != ReservationStatus.CONFIRMED
                || !reservation.getStartDate().isAfter(LocalDate.now())) {
            throw new ReservationException("Only future confirmed reservations can be deleted; keep reservation history.");
        }
        reservationRepository.delete(reservation);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AdminReservationSummary> findReservations(ReservationStatus status) {
        return reservationRepository.findAdminReservations(status);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AdminReservationSummary> findReservationsForCustomerByAdmin(Long customerId) {
        User customer = customerId == null ? null : userService.findById(customerId)
                .filter(user -> user.getRole() == Role.CUSTOMER)
                .orElse(null);
        if (customer == null) {
            throw new AdminOperationException("That customer could not be found.");
        }
        return reservationRepository.findAdminReservationsForCustomer(customerId);
    }

    private void cancelConfirmedReservation(Reservation reservation) {
        if (reservation.getStatus() != ReservationStatus.CONFIRMED) {
            throw new ReservationException("Only confirmed reservations can be cancelled.");
        }
        if (!reservation.getStartDate().isAfter(LocalDate.now())) {
            throw new ReservationException("A reservation can only be cancelled before its start date.");
        }
        reservation.setStatus(ReservationStatus.CANCELLED);
    }

    private long validateDates(LocalDate startDate, LocalDate endDate) {
        if (startDate == null || endDate == null) {
            throw new ReservationException("Choose both a start date and an end date.");
        }
        if (startDate.isBefore(LocalDate.now())) {
            throw new ReservationException("The start date cannot be in the past.");
        }
        if (!endDate.isAfter(startDate)) {
            throw new ReservationException("The end date must be after the start date.");
        }
        long rentalDays = ChronoUnit.DAYS.between(startDate, endDate);
        if (rentalDays > MAX_RENTAL_DAYS) {
            throw new ReservationException("A reservation can be no longer than 30 days.");
        }
        return rentalDays;
    }

    private User requireCustomer(Long userId) {
        Optional<User> user = userId == null ? Optional.empty() : userService.findById(userId);
        if (user.isEmpty() || user.get().getRole() != Role.CUSTOMER) {
            throw new ReservationException("Only customer accounts can manage reservations.");
        }
        return user.get();
    }
}
