package com.carrental.service;

import com.carrental.model.Role;
import com.carrental.model.User;
import com.carrental.repository.UserRepository;
import com.carrental.web.AdminCustomerSummary;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    private static final int BCRYPT_MAX_BYTES = 72;

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserServiceImpl(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional
    public User registerCustomer(String fullName, String email, String rawPassword) {
        String normalizedEmail = User.normalizeEmail(email);
        if (userRepository.existsByEmail(normalizedEmail)) {
            throw new DuplicateEmailException();
        }
        if (rawPassword.getBytes(StandardCharsets.UTF_8).length > BCRYPT_MAX_BYTES) {
            throw new IllegalArgumentException("Password is too long for secure BCrypt hashing.");
        }

        User user = new User(fullName.trim(), normalizedEmail,
                passwordEncoder.encode(rawPassword), Role.CUSTOMER);
        try {
            return userRepository.saveAndFlush(user);
        } catch (DataIntegrityViolationException exception) {
            throw new DuplicateEmailException();
        }
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<User> findById(Long id) {
        return userRepository.findById(id);
    }

    @Override
    @Transactional
    public User modifyCustomer(Long id, String fullName, String email) {
        User customer = requireCustomer(id);
        String normalizedName = fullName == null ? "" : fullName.trim();
        String normalizedEmail = User.normalizeEmail(email);
        if (normalizedName.isBlank() || normalizedName.length() > 100
                || normalizedEmail.isBlank() || normalizedEmail.length() > 254
                || !normalizedEmail.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) {
            throw new AdminOperationException("Enter a valid customer name and email address.");
        }
        userRepository.findByEmail(normalizedEmail)
                .filter(existing -> !existing.getId().equals(id))
                .ifPresent(existing -> { throw new DuplicateEmailException(); });
        customer.setFullName(normalizedName);
        customer.setEmail(normalizedEmail);
        return userRepository.save(customer);
    }

    @Override
    @Transactional
    public void deleteCustomer(Long id) {
        User customer = requireCustomer(id);
        if (userRepository.hasReservationHistory(id)) {
            throw new AdminOperationException("This customer has reservation history and cannot be deleted.");
        }
        userRepository.delete(customer);
    }

    private User requireCustomer(Long id) {
        if (id == null || id < 1) {
            throw new AdminOperationException("That customer could not be found.");
        }
        return userRepository.findById(id)
                .filter(user -> user.getRole() == Role.CUSTOMER)
                .orElseThrow(() -> new AdminOperationException("That customer could not be found."));
    }

    @Override
    @Transactional(readOnly = true)
    public List<AdminCustomerSummary> findCustomers(String search) {
        String normalizedSearch = search == null || search.isBlank() ? null : search.trim();
        if (normalizedSearch != null && normalizedSearch.length() > 254) {
            throw new AdminOperationException("Customer search must be 254 characters or fewer.");
        }
        return userRepository.searchCustomers(Role.CUSTOMER, normalizedSearch);
    }

    @Override
    @Transactional(readOnly = true)
    public AdminCustomerSummary findCustomer(Long id) {
        User customer = id == null ? null : userRepository.findById(id)
                .filter(user -> user.getRole() == Role.CUSTOMER)
                .orElse(null);
        if (customer == null) {
            throw new AdminOperationException("That customer could not be found.");
        }
        return new AdminCustomerSummary(customer.getId(), customer.getFullName(), customer.getEmail());
    }
}
