package com.carrental.service;

import com.carrental.model.Car;
import java.util.List;

public interface CarService {

    List<Car> findCars(String search, String category, boolean availableOnly);

    List<String> findCategories();

    Car findCarById(Long id);

    Car addCar(Car car);

    Car modifyCar(Long id, Car car);

    void changeAvailability(Long id, boolean available);

    void deleteCar(Long id);
}
