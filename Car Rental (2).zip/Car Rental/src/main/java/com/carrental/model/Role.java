package com.carrental.model;

public enum Role {
    CUSTOMER,
    ADMIN
}
