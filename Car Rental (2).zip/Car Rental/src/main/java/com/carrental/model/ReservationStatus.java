package com.carrental.model;

public enum ReservationStatus {
    CONFIRMED,
    CANCELLED,
    COMPLETED
}