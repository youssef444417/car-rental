package com.carrental.repository;

import com.carrental.model.Reservation;
import com.carrental.model.ReservationStatus;
import com.carrental.web.AdminReservationSummary;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface ReservationRepository extends JpaRepository<Reservation, Long> {

    @Query("select r from Reservation r join fetch r.car where r.user.id = :userId "
            + "order by r.createdAt desc, r.id desc")
    List<Reservation> findAllForUser(@Param("userId") Long userId);

    boolean existsByCar_IdAndStatusInAndStartDateLessThanAndEndDateGreaterThan(
            Long carId, Collection<ReservationStatus> statuses, LocalDate endDate, LocalDate startDate);

    @Query("select case when count(r) > 0 then true else false end from Reservation r "
            + "where r.car.id = :carId and r.id <> :reservationId and r.status in :statuses "
            + "and r.startDate < :endDate and r.endDate > :startDate")
    boolean existsOverlappingReservation(@Param("carId") Long carId, @Param("reservationId") Long reservationId,
                                         @Param("statuses") Collection<ReservationStatus> statuses,
                                         @Param("endDate") LocalDate endDate, @Param("startDate") LocalDate startDate);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select r from Reservation r where r.id = :reservationId and r.user.id = :userId")
    Optional<Reservation> findOwnedForUpdate(@Param("reservationId") Long reservationId,
                                             @Param("userId") Long userId);

        long countByStatus(ReservationStatus status);

        boolean existsByCar_Id(Long carId);

        @Lock(LockModeType.PESSIMISTIC_WRITE)
        @Query("select r from Reservation r where r.id = :reservationId")
        Optional<Reservation> findByIdForUpdate(@Param("reservationId") Long reservationId);

        @Query("""
                        select new com.carrental.web.AdminReservationSummary(
                                r.id, u.id, u.fullName, u.email, c.id, c.brand, c.model,
                                r.startDate, r.endDate, r.dailyPriceSnapshot, r.totalPrice, r.status)
                        from Reservation r join r.user u join r.car c
                        where (:status is null or r.status = :status)
                        order by r.createdAt desc, r.id desc
                        """)
        List<AdminReservationSummary> findAdminReservations(@Param("status") ReservationStatus status);

        @Query("""
                        select new com.carrental.web.AdminReservationSummary(
                                r.id, u.id, u.fullName, u.email, c.id, c.brand, c.model,
                                r.startDate, r.endDate, r.dailyPriceSnapshot, r.totalPrice, r.status)
                        from Reservation r join r.user u join r.car c
                        where u.id = :userId
                        order by r.createdAt desc, r.id desc
                        """)
        List<AdminReservationSummary> findAdminReservationsForCustomer(@Param("userId") Long userId);
}
