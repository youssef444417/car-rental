package com.carrental.repository;

import com.carrental.model.User;
import com.carrental.model.Role;
import com.carrental.model.Reservation;
import com.carrental.web.AdminCustomerSummary;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email);

    boolean existsByEmail(String email);

    long countByRole(Role role);

    @Query("select case when count(r) > 0 then true else false end from Reservation r where r.user.id = :userId")
    boolean hasReservationHistory(@Param("userId") Long userId);

    @Query("""
            select new com.carrental.web.AdminCustomerSummary(u.id, u.fullName, u.email)
            from User u
            where u.role = :role
              and (:search is null
                  or lower(u.fullName) like lower(concat('%', :search, '%'))
                  or lower(u.email) like lower(concat('%', :search, '%')))
            order by u.fullName, u.email
            """)
    List<AdminCustomerSummary> searchCustomers(@Param("role") Role role,
                                               @Param("search") String search);
}
