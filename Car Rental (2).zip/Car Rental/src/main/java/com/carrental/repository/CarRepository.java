package com.carrental.repository;

import com.carrental.model.Car;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface CarRepository extends JpaRepository<Car, Long> {

  @Lock(LockModeType.PESSIMISTIC_WRITE)
  @Query("select c from Car c where c.id = :id")
  Optional<Car> findByIdForUpdate(@Param("id") Long id);

  long countByAvailableTrue();

    @Query("""
            select c from Car c
            where (:search is null
                or lower(c.brand) like lower(concat('%', :search, '%'))
                or lower(c.model) like lower(concat('%', :search, '%')))
              and (:category is null or lower(c.category) = lower(:category))
              and (:availableOnly = false or c.available = true)
            order by c.brand, c.model
            """)
    List<Car> searchCatalog(@Param("search") String search,
                            @Param("category") String category,
                            @Param("availableOnly") boolean availableOnly);

    @Query("select distinct c.category from Car c order by c.category")
    List<String> findAllCategories();
}
