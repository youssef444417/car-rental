# Car photo sources

All four photos are free to use under the Unsplash License. Attribution is not required by that license; these records are retained for provenance.

| Vehicle record | Local file | Photographer | Source |
| --- | --- | --- | --- |
| Toyota Corolla (Sedan) | `toyota-corolla-sedan.jpg` | @bbestamis | https://unsplash.com/photos/white-sedan-on-gray-asphalt-road-during-daytime-73XAgT8DOpo |
| Volkswagen Golf (Hatchback) | `volkswagen-golf-hatchback.jpg` | @autotraderuk | https://unsplash.com/photos/a-white-volkswagen-golf-drives-on-a-road-jLba2Etjp8A |
| Hyundai Tucson (SUV) | `hyundai-tucson-suv.jpg` | @hyundaimotorgroup | https://unsplash.com/photos/a-grey-suv-parked-in-a-parking-lot-37-uFwiQLwY |
| BMW 3 Series (Luxury) | `bmw-3-series-luxury.jpg` | @eversonvansoski | https://unsplash.com/photos/a-gray-bmw-parked-on-a-street-with-grass-qRpXnvNkSHk |

License: https://unsplash.com/license