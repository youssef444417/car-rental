package com.carrental.security;

import com.carrental.model.Role;
import com.carrental.model.User;
import com.carrental.repository.UserRepository;
import com.carrental.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.response.SecurityMockMvcResultMatchers.authenticated;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrlPattern;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

@SpringBootTest(properties = {
        "app.sample-data.enabled=false",
        "spring.datasource.url=jdbc:h2:mem:carrental-security-tests;MODE=MySQL;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE",
        "spring.datasource.driver-class-name=org.h2.Driver",
        "spring.jpa.hibernate.ddl-auto=update"
})
@AutoConfigureMockMvc
class AuthenticationFlowTest {

    private static final String PASSWORD = "A-strong-test-password-93";

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UserRepository userRepository;

    @Autowired
        private UserService userService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @BeforeEach
    void clearUsers() {
        userRepository.deleteAll();
    }

    @Test
    void homepageAndCatalogArePublic() throws Exception {
        mockMvc.perform(get("/")).andExpect(status().isOk()).andExpect(view().name("index"));
        mockMvc.perform(get("/cars")).andExpect(status().isOk()).andExpect(view().name("cars"));
    }

    @Test
    void successfulRegistrationNormalizesEmailAndStoresOnlyBcryptHash() throws Exception {
        mockMvc.perform(post("/register").with(csrf())
                        .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                        .param("fullName", " Riley Example ")
                        .param("email", "  Riley.Example@Example.COM ")
                        .param("password", PASSWORD)
                        .param("confirmPassword", PASSWORD)
                        .param("role", "ADMIN"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login?registered"));

        User saved = userRepository.findByEmail("riley.example@example.com").orElseThrow();
        assertEquals("Riley Example", saved.getFullName());
        assertEquals(Role.CUSTOMER, saved.getRole());
        assertNotEquals(PASSWORD, saved.getPasswordHash());
        assertTrue(passwordEncoder.matches(PASSWORD, saved.getPasswordHash()));
        assertTrue(saved.getCreatedAt() != null);
    }

    @Test
    void duplicateEmailShowsHelpfulErrorWithoutAddingAnotherUser() throws Exception {
        register("same@example.com");

        mockMvc.perform(post("/register").with(csrf())
                        .param("fullName", "Another Person")
                        .param("email", " SAME@example.com ")
                        .param("password", PASSWORD)
                        .param("confirmPassword", PASSWORD))
                .andExpect(status().isOk())
                .andExpect(view().name("register"))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("This email is already registered")));

        assertEquals(1, userRepository.count());
    }

    @Test
    void mismatchedPasswordsAreRejected() throws Exception {
        mockMvc.perform(post("/register").with(csrf())
                        .param("fullName", "Riley Example")
                        .param("email", "riley@example.com")
                        .param("password", PASSWORD)
                        .param("confirmPassword", "A-different-password-93"))
                .andExpect(status().isOk())
                .andExpect(content().string(org.hamcrest.Matchers.containsString("The passwords do not match")))
                .andExpect(content().string(org.hamcrest.Matchers.not(
                        org.hamcrest.Matchers.containsString(PASSWORD))));

        assertEquals(0, userRepository.count());
    }

    @Test
    void loginAcceptsNormalizedEmailAndRedirectsToAccount() throws Exception {
        register("login@example.com");

        mockMvc.perform(post("/login").with(csrf())
                        .param("email", " LOGIN@example.com ")
                        .param("password", PASSWORD))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/account"))
                .andExpect(authenticated().withUsername("login@example.com"));
    }

    @Test
    void loginFailureReturnsGenericError() throws Exception {
        mockMvc.perform(post("/login").with(csrf())
                        .param("email", "unknown@example.com")
                        .param("password", "incorrect-password"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login?error"));

        mockMvc.perform(get("/login").param("error", ""))
                .andExpect(status().isOk())
                .andExpect(content().string(org.hamcrest.Matchers.containsString("We couldn't sign you in with those details")));
    }

    @Test
    void anonymousCustomerPageRedirectsToLogin() throws Exception {
        mockMvc.perform(get("/account")).andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrlPattern("**/login"));
    }

    @Test
    void authenticatedCustomerSeesAccountAndSignOutButNotAdminNavigation() throws Exception {
        register("nav-customer@example.com");
        MockHttpSession session = login("nav-customer@example.com");

        mockMvc.perform(get("/account").session(session))
                .andExpect(status().isOk())
                .andExpect(view().name("account"))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Test Customer")))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Sign out")))
                .andExpect(content().string(org.hamcrest.Matchers.not(
                        org.hamcrest.Matchers.containsString("href=\"/admin\""))));
    }

    @Test
    void customerCannotAccessAdminPage() throws Exception {
        register("customer@example.com");
        MockHttpSession session = login("customer@example.com");

        mockMvc.perform(get("/admin").session(session))
                .andExpect(status().isForbidden());
    }

    @Test
    void accessDeniedPageIsAvailable() throws Exception {
        mockMvc.perform(get("/access-denied"))
                .andExpect(status().isOk())
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Access restricted")));
    }

    @Test
    void adminCanAccessAdminLandingPage() throws Exception {
        userRepository.saveAndFlush(new User("Trusted Admin", "admin@example.com",
                passwordEncoder.encode(PASSWORD), Role.ADMIN));
        MockHttpSession session = login("admin@example.com");

        mockMvc.perform(get("/admin").session(session))
                .andExpect(status().isOk())
                .andExpect(view().name("admin"))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Access verified")))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("href=\"/admin\"")));
    }

    @Test
    void registrationAndLogoutRequireCsrfTokens() throws Exception {
        mockMvc.perform(post("/register")
                        .param("fullName", "Riley Example")
                        .param("email", "riley@example.com")
                        .param("password", PASSWORD)
                        .param("confirmPassword", PASSWORD))
                .andExpect(status().isForbidden());

        register("logout@example.com");
        MockHttpSession session = login("logout@example.com");
        mockMvc.perform(post("/logout").session(session)).andExpect(status().isForbidden());
        mockMvc.perform(post("/logout").session(session).with(csrf()))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/?logout"));
    }

    @Test
    void loginAndRegistrationPagesIncludeCsrfFields() throws Exception {
        mockMvc.perform(get("/login"))
                .andExpect(status().isOk())
                .andExpect(content().string(org.hamcrest.Matchers.containsString("name=\"_csrf\"")));
        mockMvc.perform(get("/register"))
                .andExpect(status().isOk())
                .andExpect(content().string(org.hamcrest.Matchers.containsString("name=\"_csrf\"")));
    }

    private void register(String email) {
        userService.registerCustomer("Test Customer", email, PASSWORD);
    }

    private MockHttpSession login(String email) throws Exception {
        MvcResult result = mockMvc.perform(post("/login").with(csrf())
                        .param("email", email)
                        .param("password", PASSWORD))
                .andExpect(status().is3xxRedirection())
                .andReturn();
        return (MockHttpSession) result.getRequest().getSession(false);
    }
}
