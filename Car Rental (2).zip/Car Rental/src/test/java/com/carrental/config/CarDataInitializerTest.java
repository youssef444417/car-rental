package com.carrental.config;

import com.carrental.model.Car;
import com.carrental.repository.CarRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;

@DataJpaTest
class CarDataInitializerTest {

    @Autowired
    private CarRepository carRepository;

    @Test
    void seedsLocalImagePathsForSampleCarsWhenDatabaseIsEmpty() throws Exception {
        new CarDataInitializer().loadSampleCars(carRepository).run();

        Map<String, Car> cars = carRepository.findAll().stream()
                .collect(Collectors.toMap(car -> car.getBrand() + "|" + car.getModel(), Function.identity()));

        assertEquals(4, cars.size());
        assertEquals("/images/cars/toyota-corolla-sedan.jpg", cars.get("Toyota|Corolla").getImageUrl());
        assertEquals("/images/cars/volkswagen-golf-hatchback.jpg", cars.get("Volkswagen|Golf").getImageUrl());
        assertEquals("/images/cars/hyundai-tucson-suv.jpg", cars.get("Hyundai|Tucson").getImageUrl());
        assertEquals("/images/cars/bmw-3-series-luxury.jpg", cars.get("BMW|3 Series").getImageUrl());
    }

    @Test
    void fillsOnlyBlankImageUrlsForKnownCarsWithoutChangingOtherData() throws Exception {
        Car sampleCar = new Car("Toyota", "Corolla", 2023, "Sedan", "Existing description",
                new BigDecimal("61.25"), "", false);
        Car customImageCar = new Car("Volkswagen", "Golf", 2022, "Hatchback", "Custom photo",
                new BigDecimal("72.00"), "https://example.test/custom-golf.jpg", true);
        Car unrelatedCar = new Car("Honda", "Civic", 2021, "Sedan", "Unrelated car",
                new BigDecimal("50.00"), "", true);
        carRepository.saveAllAndFlush(List.of(sampleCar, customImageCar, unrelatedCar));

        new CarDataInitializer().loadSampleCars(carRepository).run();

        Map<String, Car> cars = carRepository.findAll().stream()
                .collect(Collectors.toMap(car -> car.getBrand() + "|" + car.getModel(), Function.identity()));
        Car updatedSample = cars.get("Toyota|Corolla");
        assertEquals(3, cars.size());
        assertEquals("/images/cars/toyota-corolla-sedan.jpg", updatedSample.getImageUrl());
        assertEquals(new BigDecimal("61.25"), updatedSample.getPricePerDay());
        assertEquals(false, updatedSample.isAvailable());
        assertEquals("Existing description", updatedSample.getDescription());
        assertEquals("https://example.test/custom-golf.jpg", cars.get("Volkswagen|Golf").getImageUrl());
        assertEquals("", cars.get("Honda|Civic").getImageUrl());
    }
}