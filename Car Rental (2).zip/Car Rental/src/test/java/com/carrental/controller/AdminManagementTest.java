package com.carrental.controller;

import com.carrental.model.Car;
import com.carrental.model.Reservation;
import com.carrental.model.ReservationStatus;
import com.carrental.model.Role;
import com.carrental.model.User;
import com.carrental.repository.CarRepository;
import com.carrental.repository.ReservationRepository;
import com.carrental.repository.UserRepository;
import com.carrental.service.ReservationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.flash;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrlPattern;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

@SpringBootTest(properties = {
        "app.sample-data.enabled=false",
        "spring.datasource.url=jdbc:h2:mem:carrental-admin-tests;MODE=MySQL;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE",
        "spring.datasource.driver-class-name=org.h2.Driver",
        "spring.jpa.hibernate.ddl-auto=update"
})
@AutoConfigureMockMvc
class AdminManagementTest {

    private static final String PASSWORD = "Admin-test-password-93";

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ReservationService reservationService;

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @BeforeEach
    void clearData() {
        reservationRepository.deleteAll();
        carRepository.deleteAll();
        userRepository.deleteAll();
    }

    @Test
    void anonymousAndCustomerAreDeniedFromAdminReadsAndWrites() throws Exception {
        Car car = createCar("Toyota", "Corolla", true);
        for (String route : new String[]{"/admin", "/admin/cars", "/admin/reservations", "/admin/customers"}) {
            mockMvc.perform(get(route))
                    .andExpect(status().is3xxRedirection())
                    .andExpect(redirectedUrlPattern("**/login"));
        }

        User customer = createUser("customer@example.com", Role.CUSTOMER);
        MockHttpSession customerSession = login(customer.getEmail());
        for (String route : new String[]{"/admin", "/admin/cars", "/admin/reservations", "/admin/customers"}) {
            mockMvc.perform(get(route).session(customerSession)).andExpect(status().isForbidden());
        }
        mockMvc.perform(post("/admin/cars/{id}/availability", car.getId()).with(csrf()).session(customerSession)
                        .param("available", "false"))
                .andExpect(status().isForbidden());
        assertTrue(carRepository.findById(car.getId()).orElseThrow().isAvailable());
    }

    @Test
    void dashboardDisplaysLiveRepositoryCounts() throws Exception {
        createCar("Toyota", "Corolla", true);
        createCar("BMW", "3 Series", false);
        User customer = createUser("counts@example.com", Role.CUSTOMER);
        createUser("counts-admin@example.com", Role.ADMIN);
        Car car = carRepository.findAll().getFirst();
        saveReservation(customer, car, ReservationStatus.CONFIRMED,
                LocalDate.now().plusDays(4), LocalDate.now().plusDays(6));
        saveReservation(customer, car, ReservationStatus.CANCELLED,
                LocalDate.now().plusDays(8), LocalDate.now().plusDays(10));

        MockHttpSession adminSession = login("counts-admin@example.com");
        mockMvc.perform(get("/admin").session(adminSession))
                .andExpect(status().isOk())
                .andExpect(view().name("admin"))
                .andExpect(model().attribute("stats", new com.carrental.service.AdminService.DashboardStats(
                        2, 1, 1, 2, 1, 1)))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Access verified")));
    }

    @Test
    void adminCanCreateEditToggleAndSafelyDeleteCars() throws Exception {
        User admin = createUser("cars-admin@example.com", Role.ADMIN);
        MockHttpSession adminSession = login(admin.getEmail());

        mockMvc.perform(post("/admin/cars").with(csrf()).session(adminSession)
                        .param("brand", "Toyota")
                        .param("model", "Corolla")
                        .param("year", "2025")
                        .param("category", "Sedan")
                        .param("description", "Fleet car")
                        .param("pricePerDay", "61.25")
                        .param("imageUrl", "/images/cars/toyota-corolla-sedan.jpg")
                        .param("available", "true"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/admin/cars"));

        Car saved = carRepository.findAll().getFirst();
        assertEquals(new BigDecimal("61.25"), saved.getPricePerDay());
        assertEquals("/images/cars/toyota-corolla-sedan.jpg", saved.getImageUrl());
        mockMvc.perform(get("/admin/cars").session(adminSession))
                .andExpect(status().isOk())
                .andExpect(view().name("admin-cars"))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Toyota Corolla")));
        mockMvc.perform(get("/admin/cars/new").session(adminSession))
                .andExpect(status().isOk())
                .andExpect(view().name("admin-car-form"));
        mockMvc.perform(get("/admin/cars/{id}/edit", saved.getId()).session(adminSession))
                .andExpect(status().isOk())
                .andExpect(view().name("admin-car-form"))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Corolla")));

        mockMvc.perform(post("/admin/cars/{id}", saved.getId()).with(csrf()).session(adminSession)
                        .param("brand", "Toyota")
                        .param("model", "Corolla Cross")
                        .param("year", "2025")
                        .param("category", "SUV")
                        .param("description", "Updated fleet car")
                        .param("pricePerDay", "66.00")
                        .param("imageUrl", "/images/cars/toyota-corolla-sedan.jpg")
                        .param("available", "true"))
                .andExpect(status().is3xxRedirection());
        assertEquals("Corolla Cross", carRepository.findById(saved.getId()).orElseThrow().getModel());

        mockMvc.perform(post("/admin/cars/{id}/availability", saved.getId()).with(csrf()).session(adminSession)
                        .param("available", "false"))
                .andExpect(status().is3xxRedirection());
        assertFalse(carRepository.findById(saved.getId()).orElseThrow().isAvailable());
        mockMvc.perform(post("/admin/cars/{id}/availability", saved.getId()).with(csrf()).session(adminSession)
                        .param("available", "true"))
                .andExpect(status().is3xxRedirection());

        User customer = createUser("booker@example.com", Role.CUSTOMER);
        reservationService.createReservation(customer.getId(), saved.getId(),
                LocalDate.now().plusDays(5), LocalDate.now().plusDays(7));
        mockMvc.perform(post("/admin/cars/{id}/delete", saved.getId()).with(csrf()).session(adminSession))
                .andExpect(status().is3xxRedirection())
                .andExpect(flash().attribute("adminError",
                        org.hamcrest.Matchers.containsString("reservation history")));
        assertTrue(carRepository.existsById(saved.getId()));

        Car unusedCar = createCar("Honda", "Civic", true);
        mockMvc.perform(post("/admin/cars/{id}/delete", unusedCar.getId()).with(csrf()).session(adminSession))
                .andExpect(status().is3xxRedirection())
                .andExpect(flash().attribute("adminMessage", "Car deleted from the catalog."));
        assertFalse(carRepository.existsById(unusedCar.getId()));
    }

        @Test
        void invalidCarPriceReturnsValidationFeedbackWithoutSaving() throws Exception {
                User admin = createUser("validation-admin@example.com", Role.ADMIN);
                MockHttpSession adminSession = login(admin.getEmail());

                mockMvc.perform(post("/admin/cars").with(csrf()).session(adminSession)
                                                .param("brand", "Toyota")
                                                .param("model", "Corolla")
                                                .param("year", "2025")
                                                .param("category", "Sedan")
                                                .param("description", "Fleet car")
                                                .param("pricePerDay", "-5")
                                                .param("imageUrl", "/images/cars/toyota-corolla-sedan.jpg")
                                                .param("available", "true"))
                                .andExpect(status().isOk())
                                .andExpect(view().name("admin-car-form"))
                                .andExpect(content().string(org.hamcrest.Matchers.containsString("Daily price must be greater than zero.")));
                assertEquals(0, carRepository.count());
        }

    @Test
    void reservationStatusChangesEnforceDatesAndTransitions() throws Exception {
        User customer = createUser("status-customer@example.com", Role.CUSTOMER);
        User admin = createUser("status-admin@example.com", Role.ADMIN);
        Car car = createCar("Toyota", "Corolla", true);
        MockHttpSession adminSession = login(admin.getEmail());
        LocalDate start = LocalDate.now().plusDays(3);
        Reservation active = reservationService.createReservation(customer.getId(), car.getId(), start, start.plusDays(3));
        mockMvc.perform(get("/admin/reservations").session(adminSession).param("status", "CONFIRMED"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin-reservations"))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("status-customer@example.com")));
        mockMvc.perform(get("/admin/reservations").session(adminSession).param("status", "CANCELLED"))
                .andExpect(status().isOk())
                .andExpect(content().string(org.hamcrest.Matchers.containsString("No reservations match this filter")));

        mockMvc.perform(post("/admin/reservations/{id}/status", active.getId()).with(csrf()).session(adminSession)
                        .param("status", "COMPLETED"))
                .andExpect(status().is3xxRedirection())
                .andExpect(flash().attribute("adminError",
                        org.hamcrest.Matchers.containsString("after its end date")));
        assertEquals(ReservationStatus.CONFIRMED,
                reservationRepository.findById(active.getId()).orElseThrow().getStatus());

        mockMvc.perform(post("/admin/reservations/{id}/status", active.getId()).with(csrf()).session(adminSession)
                        .param("status", "CANCELLED"))
                .andExpect(status().is3xxRedirection())
                .andExpect(flash().attribute("adminMessage", "Reservation status updated."));
        assertEquals(ReservationStatus.CANCELLED,
                reservationRepository.findById(active.getId()).orElseThrow().getStatus());

        Reservation ended = saveReservation(customer, car, ReservationStatus.CONFIRMED,
                LocalDate.now().minusDays(4), LocalDate.now().minusDays(1));
        mockMvc.perform(post("/admin/reservations/{id}/status", ended.getId()).with(csrf()).session(adminSession)
                        .param("status", "COMPLETED"))
                .andExpect(status().is3xxRedirection());
        assertEquals(ReservationStatus.COMPLETED,
                reservationRepository.findById(ended.getId()).orElseThrow().getStatus());

        mockMvc.perform(post("/admin/reservations/{id}/status", ended.getId()).with(csrf()).session(adminSession)
                        .param("status", "CANCELLED"))
                .andExpect(status().is3xxRedirection())
                .andExpect(flash().attribute("adminError",
                        org.hamcrest.Matchers.containsString("Only confirmed reservations")));
    }

    @Test
    void adminCanModifyAndDeleteOnlyFutureConfirmedReservations() throws Exception {
        User customer = createUser("reservation-crud-customer@example.com", Role.CUSTOMER);
        User admin = createUser("reservation-crud-admin@example.com", Role.ADMIN);
        Car car = createCar("Toyota", "Corolla", true);
        MockHttpSession adminSession = login(admin.getEmail());
        LocalDate start = LocalDate.now().plusDays(4);
        Reservation reservation = reservationService.createReservation(customer.getId(), car.getId(),
                start, start.plusDays(2));

        mockMvc.perform(post("/admin/reservations/{id}/dates", reservation.getId()).with(csrf()).session(adminSession)
                        .param("startDate", start.plusDays(1).toString())
                        .param("endDate", start.plusDays(4).toString()))
                .andExpect(status().is3xxRedirection())
                .andExpect(flash().attribute("adminMessage", "Reservation dates updated."));
        Reservation modified = reservationRepository.findById(reservation.getId()).orElseThrow();
        assertEquals(start.plusDays(1), modified.getStartDate());
        assertEquals(start.plusDays(4), modified.getEndDate());
        assertEquals(new BigDecimal("165.00"), modified.getTotalPrice());

        mockMvc.perform(post("/admin/reservations/{id}/delete", reservation.getId())
                        .with(csrf()).session(adminSession))
                .andExpect(status().is3xxRedirection())
                .andExpect(flash().attribute("adminMessage", "Future reservation deleted."));
        assertFalse(reservationRepository.existsById(reservation.getId()));

        Reservation historical = saveReservation(customer, car, ReservationStatus.CANCELLED,
                LocalDate.now().minusDays(5), LocalDate.now().minusDays(3));
        mockMvc.perform(post("/admin/reservations/{id}/delete", historical.getId())
                        .with(csrf()).session(adminSession))
                .andExpect(status().is3xxRedirection())
                .andExpect(flash().attribute("adminError", org.hamcrest.Matchers.containsString("keep reservation history")));
        assertTrue(reservationRepository.existsById(historical.getId()));
    }

    @Test
    void customerSearchAndHistoryNeverExposePasswordHash() throws Exception {
        User customer = createUser("private-customer@example.com", Role.CUSTOMER);
        User adminAccount = createUser("private-admin@example.com", Role.ADMIN);
        Car car = createCar("Hyundai", "Tucson", true);
        Reservation reservation = reservationService.createReservation(customer.getId(), car.getId(),
                LocalDate.now().plusDays(2), LocalDate.now().plusDays(4));
        MockHttpSession adminSession = login(adminAccount.getEmail());
        String passwordHash = userRepository.findById(customer.getId()).orElseThrow().getPasswordHash();

        mockMvc.perform(get("/admin/customers").session(adminSession).param("search", "private-customer"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin-customers"))
                .andExpect(model().attribute("customers", org.hamcrest.Matchers.hasSize(1)))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("private-customer@example.com")))
                .andExpect(content().string(org.hamcrest.Matchers.not(org.hamcrest.Matchers.containsString(passwordHash))));

        mockMvc.perform(get("/admin/customers/{id}", customer.getId()).session(adminSession))
                .andExpect(status().isOk())
                .andExpect(view().name("admin-customer-details"))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Hyundai Tucson")))
                .andExpect(content().string(org.hamcrest.Matchers.containsString(reservation.getStatus().name())))
                .andExpect(content().string(org.hamcrest.Matchers.not(org.hamcrest.Matchers.containsString(passwordHash))));
    }

    @Test
    void adminsCanUpdateCustomerAndDeleteOnlyCustomersWithoutHistory() throws Exception {
        User admin = createUser("customer-crud-admin@example.com", Role.ADMIN);
        User customer = createUser("before-crud@example.com", Role.CUSTOMER);
        MockHttpSession adminSession = login(admin.getEmail());

        mockMvc.perform(post("/admin/customers/{id}", customer.getId()).with(csrf()).session(adminSession)
                        .param("fullName", "Updated Customer")
                        .param("email", "after-crud@example.com"))
                .andExpect(status().is3xxRedirection());
        User updated = userRepository.findById(customer.getId()).orElseThrow();
        assertEquals("Updated Customer", updated.getFullName());
        assertEquals("after-crud@example.com", updated.getEmail());
        assertEquals(Role.CUSTOMER, updated.getRole());

        mockMvc.perform(post("/admin/customers/{id}/delete", customer.getId())
                        .with(csrf()).session(adminSession))
                .andExpect(status().is3xxRedirection());
        assertFalse(userRepository.existsById(customer.getId()));

        User customerWithHistory = createUser("history-customer@example.com", Role.CUSTOMER);
        Car car = createCar("Toyota", "Corolla", true);
        saveReservation(customerWithHistory, car, ReservationStatus.CANCELLED,
                LocalDate.now().minusDays(5), LocalDate.now().minusDays(3));
        mockMvc.perform(post("/admin/customers/{id}/delete", customerWithHistory.getId())
                        .with(csrf()).session(adminSession))
                .andExpect(status().is3xxRedirection())
                .andExpect(flash().attribute("adminError", org.hamcrest.Matchers.containsString("reservation history")));
        assertTrue(userRepository.existsById(customerWithHistory.getId()));

        mockMvc.perform(post("/admin/customers/{id}", admin.getId()).with(csrf()).session(adminSession)
                        .param("fullName", "Changed Admin")
                        .param("email", "changed-admin@example.com"))
                .andExpect(status().is3xxRedirection())
                .andExpect(flash().attribute("adminError", org.hamcrest.Matchers.containsString("could not be found")));
        assertEquals("customer-crud-admin@example.com", userRepository.findById(admin.getId()).orElseThrow().getEmail());
    }

    private User createUser(String email, Role role) {
        return userRepository.saveAndFlush(new User(email, email, passwordEncoder.encode(PASSWORD), role));
    }

    private Car createCar(String brand, String model, boolean available) {
        return carRepository.saveAndFlush(new Car(brand, model, 2024, "Sedan", "Test car",
                new BigDecimal("55.00"), "", available));
    }

    private Reservation saveReservation(User customer, Car car, ReservationStatus status,
                                        LocalDate startDate, LocalDate endDate) {
        return reservationRepository.saveAndFlush(new Reservation(customer, car, startDate, endDate,
                status, new BigDecimal("55.00"), new BigDecimal("110.00")));
    }

    private MockHttpSession login(String email) throws Exception {
        MvcResult result = mockMvc.perform(post("/login").with(csrf())
                        .param("email", email)
                        .param("password", PASSWORD))
                .andExpect(status().is3xxRedirection())
                .andReturn();
        return (MockHttpSession) result.getRequest().getSession(false);
    }
}
