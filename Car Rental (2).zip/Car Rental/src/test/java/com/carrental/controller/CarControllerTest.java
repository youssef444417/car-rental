package com.carrental.controller;

import com.carrental.model.Car;
import com.carrental.config.SecurityConfig;
import com.carrental.security.CustomUserDetailsService;
import com.carrental.service.CarService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.util.List;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

@WebMvcTest(CarController.class)
@Import(SecurityConfig.class)
class CarControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private CarService carService;

    @MockitoBean
    private CustomUserDetailsService userDetailsService;

    @Test
    void catalogPassesFiltersToServiceAndReturnsCatalogView() throws Exception {
        when(carService.findCars("Toyota", "SUV", true)).thenReturn(List.of());
        when(carService.findCategories()).thenReturn(List.of("SUV", "Sedan"));

        mockMvc.perform(get("/cars")
                        .param("search", "Toyota")
                        .param("category", "SUV")
                        .param("available", "true"))
                .andExpect(status().isOk())
                .andExpect(view().name("cars"))
                .andExpect(model().attribute("availableOnly", true))
                .andExpect(model().attribute("selectedCategory", "SUV"))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("No cars found")))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("href=\"/cars\"")));

        verify(carService).findCars("Toyota", "SUV", true);
    }

    @Test
    void detailsReturnsCarDetailsView() throws Exception {
        Car car = new Car("Toyota", "Corolla", 2023, "Sedan", "Compact sedan",
                new BigDecimal("45.00"), "", true);
        car.setImageUrl("/images/cars/toyota-corolla-sedan.jpg");
        car.setId(7L);
        when(carService.findCarById(7L)).thenReturn(car);

        mockMvc.perform(get("/cars/7"))
                .andExpect(status().isOk())
                .andExpect(view().name("car-details"))
                .andExpect(model().attribute("car", car))
                .andExpect(content().string(org.hamcrest.Matchers.containsString(
                    "src=\"/images/cars/toyota-corolla-sedan.jpg\"")))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("href=\"/cars?available=true\"")));
    }

            @Test
            void catalogRendersTheLocalImageUrlForEachCar() throws Exception {
            Car car = new Car("Volkswagen", "Golf", 2022, "Hatchback", "Compact hatchback",
                new BigDecimal("52.00"), "/images/cars/volkswagen-golf-hatchback.jpg", true);
            car.setId(8L);
            when(carService.findCars(null, null, false)).thenReturn(List.of(car));
            when(carService.findCategories()).thenReturn(List.of("Hatchback"));

            mockMvc.perform(get("/cars"))
                .andExpect(status().isOk())
                .andExpect(view().name("cars"))
                .andExpect(content().string(org.hamcrest.Matchers.containsString(
                    "src=\"/images/cars/volkswagen-golf-hatchback.jpg\"")));
            }

    @Test
    void detailsReturns404WhenCarDoesNotExist() throws Exception {
        when(carService.findCarById(404L)).thenThrow(
                new ResponseStatusException(HttpStatus.NOT_FOUND, "Car not found"));

        mockMvc.perform(get("/cars/404")).andExpect(status().isNotFound());
    }
}
