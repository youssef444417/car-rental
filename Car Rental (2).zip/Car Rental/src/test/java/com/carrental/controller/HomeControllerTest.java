package com.carrental.controller;

import com.carrental.config.SecurityConfig;
import com.carrental.security.CustomUserDetailsService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.List;

@WebMvcTest(HomeController.class)
@Import(SecurityConfig.class)
class HomeControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private CustomUserDetailsService userDetailsService;

    @Test
    void homepageRendersSharedNavigationAndExistingCatalogSearchRoute() throws Exception {
        mockMvc.perform(get("/"))
                .andExpect(status().isOk())
                .andExpect(view().name("index"))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Find the drive")))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("action=\"/cars\"")))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("href=\"/css/style.css\"")))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Why Car Rental")))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("src=\"/images/car-rental-logo.svg\"")))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Sign in")))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Create account")));
    }

    @Test
    void cssAndFallbackImageAreServedFromStaticResources() throws Exception {
        mockMvc.perform(get("/css/style.css"))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.valueOf("text/css")));

        mockMvc.perform(get("/images/car-placeholder.svg"))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.valueOf("image/svg+xml")));
        mockMvc.perform(get("/images/car-rental-logo.svg"))
            .andExpect(status().isOk())
            .andExpect(content().contentTypeCompatibleWith(MediaType.valueOf("image/svg+xml")));
        for (String imagePath : List.of(
            "/images/cars/toyota-corolla-sedan.jpg",
            "/images/cars/volkswagen-golf-hatchback.jpg",
            "/images/cars/hyundai-tucson-suv.jpg",
            "/images/cars/bmw-3-series-luxury.jpg")) {
            mockMvc.perform(get(imagePath))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.IMAGE_JPEG));
        }
    }
}
