package com.carrental.service;

import com.carrental.model.Car;
import com.carrental.repository.CarRepository;
import com.carrental.repository.ReservationRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CarServiceTest {

    @Mock
    private CarRepository carRepository;

    @Mock
    private ReservationRepository reservationRepository;

    @InjectMocks
    private CarServiceImpl carService;

    @Test
    void findCarsTrimsFiltersAndDelegatesToRepository() {
        List<Car> cars = List.of(car());
        when(carRepository.searchCatalog("Toyota", "Sedan", true)).thenReturn(cars);

        List<Car> result = carService.findCars(" Toyota ", " Sedan ", true);

        assertEquals(cars, result);
        verify(carRepository).searchCatalog("Toyota", "Sedan", true);
    }

    @Test
    void rejectsOverlongSearchBeforeCallingRepository() {
        String longSearch = "x".repeat(81);

        ResponseStatusException exception = assertThrows(ResponseStatusException.class,
                () -> carService.findCars(longSearch, null, false));

        assertEquals(HttpStatus.BAD_REQUEST, exception.getStatusCode());
        verifyNoInteractions(carRepository);
    }

    @Test
    void returnsNotFoundForUnknownCarId() {
        when(carRepository.findById(42L)).thenReturn(Optional.empty());

        ResponseStatusException exception = assertThrows(ResponseStatusException.class,
                () -> carService.findCarById(42L));

        assertEquals(HttpStatus.NOT_FOUND, exception.getStatusCode());
    }

    @Test
    void addsCarThroughRepository() {
        Car car = car();
        when(carRepository.save(car)).thenReturn(car);

        assertEquals(car, carService.addCar(car));

        verify(carRepository).save(car);
    }

    @Test
    void modifiesExistingCarWithoutReplacingItsIdentity() {
        Car existing = car();
        existing.setId(12L);
        Car updated = new Car("Toyota", "Corolla Cross", 2025, "SUV", "Updated car",
                new BigDecimal("61.00"), "/images/cars/toyota-corolla-sedan.jpg", false);
        when(carRepository.findById(12L)).thenReturn(Optional.of(existing));
        when(carRepository.save(existing)).thenReturn(existing);

        Car result = carService.modifyCar(12L, updated);

        assertEquals(12L, result.getId());
        assertEquals("Corolla Cross", result.getModel());
        assertEquals("SUV", result.getCategory());
        assertEquals(new BigDecimal("61.00"), result.getPricePerDay());
        assertEquals(false, result.isAvailable());
        verify(carRepository).save(existing);
    }

    @Test
    void refusesToDeleteCarWithReservationHistory() {
        Car existing = car();
        existing.setId(12L);
        when(carRepository.findById(12L)).thenReturn(Optional.of(existing));
        when(reservationRepository.existsByCar_Id(12L)).thenReturn(true);

        AdminOperationException exception = assertThrows(AdminOperationException.class,
                () -> carService.deleteCar(12L));

        assertEquals(true, exception.getMessage().contains("reservation history"));
        verify(carRepository, never()).delete(existing);
    }

    @Test
    void deletesCarWithoutReservationHistory() {
        Car existing = car();
        existing.setId(12L);
        when(carRepository.findById(12L)).thenReturn(Optional.of(existing));
        when(reservationRepository.existsByCar_Id(12L)).thenReturn(false);

        carService.deleteCar(12L);

        verify(carRepository).delete(existing);
        verify(carRepository).flush();
    }

    private Car car() {
        return new Car("Toyota", "Corolla", 2023, "Sedan", "Compact sedan",
                new BigDecimal("45.00"), "", true);
    }
}
