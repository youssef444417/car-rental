package com.carrental.service;

import com.carrental.model.Car;
import com.carrental.model.Reservation;
import com.carrental.model.ReservationStatus;
import com.carrental.model.Role;
import com.carrental.model.User;
import com.carrental.repository.CarRepository;
import com.carrental.repository.ReservationRepository;
import com.carrental.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrlPattern;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(properties = {
        "app.sample-data.enabled=false",
        "spring.datasource.url=jdbc:h2:mem:carrental-reservation-tests;MODE=MySQL;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE",
        "spring.datasource.driver-class-name=org.h2.Driver",
        "spring.jpa.hibernate.ddl-auto=update"
})
@AutoConfigureMockMvc
class ReservationFlowTest {

    private static final String PASSWORD = "Reservation-test-password-93";

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ReservationService reservationService;

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @BeforeEach
    void clearData() {
        reservationRepository.deleteAll();
        carRepository.deleteAll();
        userRepository.deleteAll();
    }

    @Test
    void bookingUsesAuthenticatedCustomerAndStoresPriceSnapshot() throws Exception {
        User customer = createUser("customer@example.com", Role.CUSTOMER);
        User anotherCustomer = createUser("other@example.com", Role.CUSTOMER);
        Car car = createCar("45.50");
        MockHttpSession session = login(customer.getEmail());
        LocalDate startDate = LocalDate.now().plusDays(2);
        LocalDate endDate = startDate.plusDays(3);

        mockMvc.perform(post("/cars/{carId}/reservations", car.getId()).with(csrf()).session(session)
                        .param("startDate", startDate.toString())
                        .param("endDate", endDate.toString())
                        .param("userId", anotherCustomer.getId().toString()))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/account/reservations"));

        Reservation reservation = reservationRepository.findAllForUser(customer.getId()).getFirst();
        assertEquals(ReservationStatus.CONFIRMED, reservation.getStatus());
        assertEquals(customer.getId(), reservation.getUser().getId());
        assertEquals(new BigDecimal("45.50"), reservation.getDailyPriceSnapshot());
        assertEquals(new BigDecimal("136.50"), reservation.getTotalPrice());
        assertNotNull(reservation.getCreatedAt());

        mockMvc.perform(get("/account/reservations").session(session))
                .andExpect(status().isOk())
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Camry")))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("136.50")))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("CONFIRMED")))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Cancel reservation")));
    }

    @Test
    void invalidDatesAndDurationsAreRejected() {
        User customer = createUser("dates@example.com", Role.CUSTOMER);
        Car car = createCar("45.50");
        LocalDate today = LocalDate.now();

        assertThrows(ReservationException.class, () -> reservationService.createReservation(
                customer.getId(), car.getId(), today.minusDays(1), today.plusDays(1)));
        assertThrows(ReservationException.class, () -> reservationService.createReservation(
                customer.getId(), car.getId(), today.plusDays(1), today.plusDays(1)));
        assertThrows(ReservationException.class, () -> reservationService.createReservation(
                customer.getId(), car.getId(), today.plusDays(1), today.plusDays(32)));
        assertEquals(0, reservationRepository.count());
    }

        @Test
        void invalidBookingDatesShowFormValidationMessage() throws Exception {
                User customer = createUser("invalid-form@example.com", Role.CUSTOMER);
                Car car = createCar("45.50");
                MockHttpSession session = login(customer.getEmail());
                LocalDate today = LocalDate.now();

                mockMvc.perform(post("/cars/{carId}/reservations", car.getId()).with(csrf()).session(session)
                                                .param("startDate", today.minusDays(1).toString())
                                                .param("endDate", today.plusDays(1).toString()))
                                .andExpect(status().isOk())
                                .andExpect(content().string(org.hamcrest.Matchers.containsString("The start date cannot be in the past.")));
                assertEquals(0, reservationRepository.count());
        }

    @Test
    void confirmedOverlapsBlockButAdjacentIntervalsAreAllowed() {
        User customer = createUser("overlap@example.com", Role.CUSTOMER);
        Car car = createCar("45.50");
        LocalDate startDate = LocalDate.now().plusDays(2);
        LocalDate endDate = startDate.plusDays(3);

        reservationService.createReservation(customer.getId(), car.getId(), startDate, endDate);

        assertThrows(ReservationException.class, () -> reservationService.createReservation(
                customer.getId(), car.getId(), endDate.minusDays(1), endDate.plusDays(2)));
        reservationService.createReservation(customer.getId(), car.getId(), endDate, endDate.plusDays(2));
        assertEquals(2, reservationRepository.count());
    }

    @Test
    void customersCanOnlyViewAndCancelTheirOwnEligibleReservations() throws Exception {
        User owner = createUser("owner@example.com", Role.CUSTOMER);
        User other = createUser("other-owner@example.com", Role.CUSTOMER);
        Car car = createCar("45.50");
        LocalDate startDate = LocalDate.now().plusDays(2);
        Reservation reservation = reservationService.createReservation(owner.getId(), car.getId(),
                startDate, startDate.plusDays(2));
        MockHttpSession ownerSession = login(owner.getEmail());
        MockHttpSession otherSession = login(other.getEmail());

        mockMvc.perform(get("/account/reservations").session(otherSession))
                .andExpect(status().isOk())
                .andExpect(content().string(org.hamcrest.Matchers.containsString("No reservations yet")))
                .andExpect(content().string(org.hamcrest.Matchers.not(org.hamcrest.Matchers.containsString("Camry"))));

        mockMvc.perform(post("/account/reservations/{id}/cancel", reservation.getId())
                        .with(csrf()).session(otherSession))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/account/reservations"));
        assertEquals(ReservationStatus.CONFIRMED,
                reservationRepository.findById(reservation.getId()).orElseThrow().getStatus());

        mockMvc.perform(post("/account/reservations/{id}/cancel", reservation.getId())
                        .with(csrf()).session(ownerSession))
                .andExpect(status().is3xxRedirection());
        assertEquals(ReservationStatus.CANCELLED,
                reservationRepository.findById(reservation.getId()).orElseThrow().getStatus());
        mockMvc.perform(get("/account/reservations").session(ownerSession))
                .andExpect(status().isOk())
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Your reservation was cancelled.")));

        Reservation completed = new Reservation(owner, car, startDate.plusDays(5), startDate.plusDays(7),
                ReservationStatus.COMPLETED, new BigDecimal("45.50"), new BigDecimal("91.00"));
        reservationRepository.saveAndFlush(completed);
        assertThrows(ReservationException.class,
                () -> reservationService.cancelReservation(owner.getId(), completed.getId()));

        Reservation alreadyStarted = new Reservation(owner, car, LocalDate.now().minusDays(2),
                LocalDate.now().plusDays(1), ReservationStatus.CONFIRMED,
                new BigDecimal("45.50"), new BigDecimal("136.50"));
        reservationRepository.saveAndFlush(alreadyStarted);
        assertThrows(ReservationException.class,
                () -> reservationService.cancelReservation(owner.getId(), alreadyStarted.getId()));

        Reservation startsToday = new Reservation(owner, car, LocalDate.now(), LocalDate.now().plusDays(2),
                ReservationStatus.CONFIRMED, new BigDecimal("45.50"), new BigDecimal("91.00"));
        reservationRepository.saveAndFlush(startsToday);
        assertThrows(ReservationException.class,
                () -> reservationService.cancelReservation(owner.getId(), startsToday.getId()));
    }

    @Test
    void reservationRoutesRequireCustomerAuthenticationAndCsrf() throws Exception {
        Car car = createCar("45.50");
        User customer = createUser("csrf-customer@example.com", Role.CUSTOMER);
        MockHttpSession customerSession = login(customer.getEmail());
        LocalDate startDate = LocalDate.now().plusDays(1);

        mockMvc.perform(post("/cars/{carId}/reservations", car.getId()).session(customerSession)
                        .param("startDate", startDate.toString())
                        .param("endDate", startDate.plusDays(1).toString()))
                .andExpect(status().isForbidden());

        Reservation reservation = reservationService.createReservation(customer.getId(), car.getId(),
                startDate, startDate.plusDays(1));
        mockMvc.perform(post("/account/reservations/{id}/cancel", reservation.getId()).session(customerSession))
                .andExpect(status().isForbidden());
        assertEquals(ReservationStatus.CONFIRMED,
                reservationRepository.findById(reservation.getId()).orElseThrow().getStatus());

        mockMvc.perform(get("/account/reservations"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrlPattern("**/login"));
        mockMvc.perform(post("/cars/{carId}/reservations", car.getId())
                        .param("startDate", LocalDate.now().plusDays(1).toString())
                        .param("endDate", LocalDate.now().plusDays(2).toString()))
                .andExpect(status().isForbidden());

        User admin = createUser("admin@example.com", Role.ADMIN);
        MockHttpSession adminSession = login(admin.getEmail());
        mockMvc.perform(get("/account/reservations").session(adminSession))
                .andExpect(status().isForbidden());
        mockMvc.perform(post("/cars/{carId}/reservations", car.getId()).with(csrf()).session(adminSession)
                        .param("startDate", LocalDate.now().plusDays(1).toString())
                        .param("endDate", LocalDate.now().plusDays(2).toString()))
                .andExpect(status().isForbidden());
        assertEquals(1, reservationRepository.count());
    }

    private User createUser(String email, Role role) {
        return userRepository.saveAndFlush(new User(email, email, passwordEncoder.encode(PASSWORD), role));
    }

    private Car createCar(String dailyPrice) {
        return carRepository.saveAndFlush(new Car("Toyota", "Camry", 2024, "Sedan", "Test car",
                new BigDecimal(dailyPrice), "", true));
    }

    private MockHttpSession login(String email) throws Exception {
        MvcResult result = mockMvc.perform(post("/login").with(csrf())
                        .param("email", email)
                        .param("password", PASSWORD))
                .andExpect(status().is3xxRedirection())
                .andReturn();
        return (MockHttpSession) result.getRequest().getSession(false);
    }
}