# Local authentication setup

## Local database settings

The default local configuration uses a file-based H2 database at `./data/carrentaldb.mv.db`, relative to the application working directory (normally the project root). H2 creates the `data` directory when needed. It does not require a MySQL server, and its contents persist across application restarts. The default Hibernate setting is `update`, which creates or adds missing structures without dropping existing tables. The H2 web console is disabled.

If you previously used the default in-memory H2 database, its contents existed only in that running process. They cannot be recovered after that process stopped and are not automatically migrated to the file database.

If you use MySQL, create the database manually before starting the application:

```sql
CREATE DATABASE carrental CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

Configure the following environment variables in the Eclipse Run Configuration. Keep credentials in the environment and out of source control:

```text
DB_URL=jdbc:mysql://localhost:3306/carrental?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
DB_DRIVER=com.mysql.cj.jdbc.Driver
DB_DIALECT=org.hibernate.dialect.MySQLDialect
DB_USERNAME=<your MySQL username>
DB_PASSWORD=<your MySQL password>
JPA_DDL_AUTO=update
```

`update` is intended for local development. For a database whose schema is managed separately, set `JPA_DDL_AUTO=none`. Do not use `create` or `create-drop` with data you want to retain.

The default application port remains `8081`; it can be changed with `PORT`. Session cookies are HTTP-only and use SameSite=Lax. Set `SESSION_COOKIE_SECURE=true` when serving the application over HTTPS.

## Enable a trusted administrator account

Public registration always creates a `CUSTOMER`; the registration form does not accept a role. There is no default administrator account. To grant administrator access to a trusted account:

1. Start the application with the selected local database and register that person's account.
2. Connect to that same database using an authorized database administrator account.
3. Confirm the normalized email and current role:

   ```sql
   SELECT id, full_name, email, role
   FROM app_users
   WHERE email = 'trusted.person@example.com';
   ```

4. After confirming the row, update only that account:

   ```sql
   UPDATE app_users
   SET role = 'ADMIN'
   WHERE email = 'trusted.person@example.com'
     AND role = 'CUSTOMER';
   ```

The entity maps to `app_users`; email addresses are trimmed and lowercased before saving; roles are stored as the strings `CUSTOMER` or `ADMIN`. Use the actual registered email in both statements. Never promote an account solely because it was first to register.

## Sample cars

The existing development sample-car initializer is preserved. It runs only with the `dev` profile when `SAMPLE_DATA_ENABLED=true`, and only when the cars table is empty. It can be disabled by setting `SAMPLE_DATA_ENABLED=false`.
